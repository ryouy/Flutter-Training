abstract class AppAssets {
  AppAssets._();
  static const String appAssetImageSource = 'assets/images';

  static const sampleAsset = '$appAssetImageSource/...';
}
