// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folder_entities.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_FolderEntity _$$_FolderEntityFromJson(Map<String, dynamic> json) =>
    _$_FolderEntity(
      id: json['id'] as String,
      name: json['name'] as String,
      dateCreated: json['dateCreated'] as String,
      dateUpdated: json['dateUpdated'] as String,
    );

Map<String, dynamic> _$$_FolderEntityToJson(_$_FolderEntity instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'dateCreated': instance.dateCreated,
      'dateUpdated': instance.dateUpdated,
    };
