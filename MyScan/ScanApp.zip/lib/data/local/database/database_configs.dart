abstract class DatabaseConfigs {
  DatabaseConfigs._();

  static const databaseName = 'my_scans.db';
  static const databaseVersion = 1;
}
