import 'dart:ui';

abstract class AppColors {
  AppColors._();

  static const Color exam = Color(0xFFFFFFFF);
}
